ROBLOX Linked Bomb
Ripped by HellFire2345 / Miles56 

The Linked BrickBattle Bomb.